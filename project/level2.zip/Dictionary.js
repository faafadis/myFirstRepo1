var http = require('http');
var url = require('url');
var fs = require('fs');
var word=require('./word.js')
var word2=require('./word2.js')


http.createServer(function(req,res){
    var q=url.parse(req.url, true)
    var qdata=q.query;
    var filename = "." + q.pathname;
    console.log(q.pathname);
    //console.log(word.filename);
    
    if (q.pathname === "/word.js")
 {
   console.log(qdata)
        word.search(req, res, qdata);
   
}
else if(q.pathname === "/word2.js"){
   // console.log(word2.filename);
    console.log("inside word2");
    console.log(qdata)
    word2.search(req, res, qdata);  
}
else if(q.pathname === "/")
{
fs.readFile('dict.html', function(err, data) {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write(data);
    return res.end();
  });
}

 
// else
// fs.readFile(filename, function(err, data) { if (err) {
// res.writeHead(404, {'Content-Type': 'text/html'});
//       return res.end("404 Not Found");
//     }
// res.writeHead(200); // Content-Type not included 
// res.write(data);
// return res.end();
//   });
// }).listen(8020);
}).listen(8097);