exports.search =function(req, res,vals){
 
    
    var mysql = require('mysql');
    
    var con = mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "mysqlmysql",
        database: "entries"
    });

con.connect(function(err) {
    if (err) throw err;
    con.query(`SELECT definition FROM entries.entries  where word = '${vals.wordSearch}'`, function (err, result, fields) {
        //con.query("SELECT definition  FROM entries.entries where word = 'boy'", function (err, result, fields) {
      if (err) throw err;
        //    console.log(fields.values.toString);
        
        
       
        
        
        //for(let i=0 ;i<array.length)
  
  
        
      
        res.writeHead(200, {'Content-Type': 'json'});
        var arr = result;
        res.write(JSON.stringify(result));
    //     res.write("<p>");
    //     for (var i = 0; i < arr.length; i++)
    //     {
    //             res.write("<br><br>definition : " + (i+1));
    //             var obj = arr[i];
    //             for (var key in obj)
    //             {
    //                 var value = obj[key];
    //                 res.write("<br> - "+ ": " + value);
    //                 console.log(value);
    //             }
    //     }
      
    //   res.write("</p>");
    //  //res.write("<a href='http://localhost:8097/dict.html'>home</a>");

    //   console.log("mamamia ");
      return res.end();
     
  
    });
});
}