
$(document).ready(function(){
$("#submit").click(findword);

function handleResponse(data) {
    console.log("handleResponse");
    console.log(data);
    // console.log("response is "+responseObj.status+" and "+responseObj.text);
    //  alert("we r here");
    //  console.log(data);
    //    $("#main").html(res.text());
      
    
}

function findword (e) {
    e.preventDefault();
    console.log($("#wordSearch").val() +"here");
    var where = $("#form").attr("action");
    
    var fe = $("#wordSearch").val();
    var what = { wordSearch: fe };
    console.log("here");
    //$.get( "http://localhost:8097/word.js", what, handleResponse, "html");
   $.get( where, what, handleResponse, "json");
//$.post( "http://localhost:8097/word2.js", what, handleResponse, "html");
    

}  
});