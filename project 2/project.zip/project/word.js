exports.search =function(req, res ,vals){
//req manupulate
// return res
var mysql = require('mysql');


var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Yt12345678",
  database: "entries"
});

con.connect(function(err) {
  if (err) throw err;
  con.query(`SELECT definition FROM entries.entries ${vals.wordSearch}`, function (err, result, fields) {
   // con.query("SELECT definition  FROM entries.entries where word = 'Abet'", function (err, result, fields) {
    if (err) throw err;
//    console.log(fields.values.toString);


   res.writeHead(200, {'Content-Type': 'text/html'});
      res.write("<!DOCTYPE html>");
    res.write("<html>");
    res.write("<head><meta charset=\"utf-8\"/>"); 
    res.write("<title>Calculator Web Site</title>");
     res.write("</head>");
    res.write("<body>");
   // res.write("<p>"+resulttext +": ");
   var string=JSON.stringify(result);
    res.write(String(string));
    
    res.write("</p>");
    res.write("<a href='http://127.0.0.1:5500/server2.html'>home</a>");
    res.write("</body>");
    res.write("</html>");
    return res.end();
   

  });
});


}