Dictionary Lookup 
